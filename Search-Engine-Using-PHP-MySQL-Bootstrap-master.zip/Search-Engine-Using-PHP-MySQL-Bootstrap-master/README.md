# Search-Engine-Using-PHP-MySQL-Bootstrap
This is a small project done by me and my friends. It's a small search engine that will work like google search engine but using only the data that we have store in our database. We have use Xampp server for the local database.
